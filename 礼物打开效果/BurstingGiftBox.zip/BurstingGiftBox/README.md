Merry Christmas with a Bursting Gift Box
=========

The Codrops team wishes everybody a Merry Christmas and a happy new year! A big "Thank You" from us in form of a little demo with a bursting animated gift box and some flying icons.

[Article on Codrops](http://tympanus.net/codrops/?p=17978)

[Demo](http://tympanus.net/Development/BurstingGiftBox/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".

Read more here: [License](http://tympanus.net/codrops/licensing/)

[SVG Christmas Icons](http://www.webappers.com/2013/12/11/free-download-100-christmas-vector-icons/) from WebAppers, designed by the team behind [FreePic](http://www.freepik.com/)

Background image from [DragonArtz Designs](http://dragonartz.wordpress.com/tag/pinetree/)

[© Codrops 2013](http://www.codrops.com)